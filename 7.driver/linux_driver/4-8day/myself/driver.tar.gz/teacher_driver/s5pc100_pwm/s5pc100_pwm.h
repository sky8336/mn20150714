#ifndef __S5PC100_LED_HHHH
#define __S5PC100_LED_HHHH

//need arg = 0/1/2/3
#define PWM_ON 	_IO('K', 0)
#define PWM_OFF _IO('K', 1)
#define SET_PRE _IO('K', 2)
#define SET_CNT _IO('K', 3)

#endif
